import PropertiesListingSection from '../sections/PropertiesListingSection';

export default function PropertiesPage() {
  return <PropertiesListingSection />;
}
