import BlogSection from '../sections/BlogSection';

export default function BlogPage() {
  return <BlogSection />;
}
