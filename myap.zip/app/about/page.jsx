import AboutUsSection from '../sections/AboutUsSection';

export default function AboutPage() {
  return <AboutUsSection />;
}
